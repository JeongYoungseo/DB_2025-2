create table 회원 (
    회원아이디 varchar(20) not null PRIMARY key,
    비밀번호 varchar(20) not null,
    이름 varchar(20) not null,
    나이 integer,
    직업 varchar2(20),
    등급 varchar2(20) default 'silver' not null,
    적립금 int default 0 not null,
    check (나이 >= 0),
    check (등급 in ('silver', 'gold', 'vip'))
);

create table 제조업체 (
    제조업체명 varchar(50) not null primary key,
    전화번호 varchar(50) not null,
    위치 varchar(50) not null,
    담당자 varchar(20) not null
);

create table 상품 (
    상품번호 varchar(20) not null primary key,
    상품명 varchar(50) not null,
    재고량 integer default 0 not null,
    단가 integer DEFAULT 0 not null,
    제조업체명 varchar(30) not null,
    공급일자 date not null,
    공급량 int default 0 not null,
    FOREIGN key (제조업체명) REFERENCES 제조업체(제조업체명),
    check (재고량 >= 0),
    check (단가 >= 0)
);

create table 주문 (
    주문번호 varchar(50) not null primary key,
    배송지 varchar(50) not null,
    주문일자 date not null,
    수량 int default 0 not null,
    회원아이디 varchar(20) not null,
    상품번호 varchar(20) not null,
    FOREIGN key (회원아이디) REFERENCES 회원(회원아이디),
    FOREIGN key (상품번호) REFERENCES 상품(상품번호),
    check (수량 >= 0)
);

create table 게시물 (
    글번호 varchar(20) not null, 
    글제목 varchar(50) not null,
    글내용 varchar(1000) not null,
    작성자 varchar(50) not null,
    회원아이디 varchar(20) not null,
    FOREIGN key (회원아이디) REFERENCES 회원(회원아이디)
);