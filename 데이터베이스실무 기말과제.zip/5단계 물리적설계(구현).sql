create table 배달회원 (
    회원아이디 varchar(20) not null PRIMARY key,
    비밀번호 varchar(20) not null,
    이름 varchar(20) not null,
    연락처 varchar(20),
    주소 varchar(100),
    역할 varchar(10) not null,
    check (역할 in ('고객', '점주', '배달기사'))
);

create table 가게 (
    가게아이디 varchar(20) not null primary key,
    점주아이디 varchar(20) not null,
    가게명 varchar(30) not null,
    주소 varchar(100) not null,
    FOREIGN key (점주아이디) REFERENCES 배달회원(회원아이디)
);

create table 메뉴 (
    메뉴아이디 varchar(20) not null primary key,
    가게아이디 varchar(20) not null,
    메뉴명 varchar(20) not null,
    가격 integer not null,
    설명 varchar(150),
    FOREIGN key (가게아이디) REFERENCES 가게(가게아이디),
    check (가격 >= 0)
);

create table 배달주문 (
    주문번호 varchar(20) not null primary key,
    고객아이디 varchar(20) not null,
    가게아이디 varchar(20) not null,
    주문시간 date not null,
    요청사항 varchar(100),
    주문상태 varchar(20) not null,
    FOREIGN key (고객아이디) REFERENCES 배달회원(회원아이디),
    FOREIGN key (가게아이디) REFERENCES 가게(가게아이디),
    check (주문상태 in ('접수', '조리중', '배달완료'))
);

create table 주문상세 (
    주문번호 varchar(20) not null,
    메뉴아이디 varchar(20) not null, 
    수량 int not null,
    금액 int not null,
    primary key(주문번호, 메뉴아이디),
    FOREIGN key (주문번호) REFERENCES 배달주문(주문번호),
    FOREIGN key (메뉴아이디) REFERENCES 메뉴(메뉴아이디),
    check (수량 >= 1),
    check (금액 >= 0)
);

create table 배달 (
    배달아이디 varchar(20) not null primary key,
    주문번호 varchar(20) not null, 
    배달기사아이디 varchar(20) not null,
    수락여부 varchar(10) not null,
    시작시간 date not null,
    완료시간 date not null,
    FOREIGN key (주문번호) REFERENCES 배달주문(주문번호),
    FOREIGN key (배달기사아이디) REFERENCES 배달회원(회원아이디),
    check (수락여부 in ('접수', '불가'))
);

create table 결제 (
    결제번호 varchar(20) not null primary key,
    주문번호 varchar(20) not null, 
    결제수단 varchar(20) not null,
    결제금액 int not null,
    결제일자 date not null,
    결제상태 varchar(20) not null,
    FOREIGN key (주문번호) REFERENCES 배달주문(주문번호),
    check (결제수단 in ('카드', '현금')),
    check (결제상태 in ('결제전','결제완료'))
);